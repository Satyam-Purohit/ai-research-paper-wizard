// A simple Node.js server using the Express framework to securely call the Gemini API.

// 1. Import necessary packages
const express = require('express');
const axios = require('axios');
const cors = require('cors'); 
require('dotenv').config(); 

// 2. Initialize the Express app
const app = express();

// 3. Enable CORS and JSON parsing
app.use(cors()); 
app.use(express.json()); 

// 4. Get the secret API key from the .env file
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;

// 5. Create the API endpoint
app.post('/generate-paper', async (req, res) => {
    try {
        const { prompt } = req.body;
        if (!prompt) {
            return res.status(400).json({ error: 'Prompt is required.' });
        }

        // 6. Securely call the Gemini API from the backend
        const geminiResponse = await axios.post(GEMINI_API_URL, {
            contents: [{ role: "user", parts: [{ text: prompt }] }]
        });
        
        // 7. Send the result back to the frontend
        res.json(geminiResponse.data);

    } catch (error) {
        console.error("Error calling Gemini API:", error.response ? error.response.data : error.message);
        res.status(500).json({ error: 'An error occurred while communicating with the AI service.' });
    }
});

// 8. Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
