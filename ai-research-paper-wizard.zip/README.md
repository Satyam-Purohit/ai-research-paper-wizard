
# AI Research Paper Wizard

## 🧠 Description
This is a full web application to generate research papers using Gemini AI.

## 🧩 Folder Structure
- `public/index.html` → Frontend
- `server.js` → Backend API server (Node.js + Express)
- `.env.example` → Add your Gemini API key here as GEMINI_API_KEY
- `package.json` → Node.js dependencies for Render.com

## 🚀 How to Deploy
1. Create a **Private** repository on GitHub
2. Upload these files
3. Connect your GitHub repo to [https://render.com](https://render.com)
4. Add environment variable:
   - Key: `GEMINI_API_KEY`
   - Value: your Gemini API key (keep it private)
5. Deploy!

Your app will be live in minutes.

## 🔐 Notes
- NEVER expose `.env` or API key publicly.
- You can also deploy frontend separately using [Netlify.com](https://netlify.com)

